//	�����`��USB ���x�v�L�b�g�p���C�u����
//		Ver001	2011/03/01	����

#include <p18f2550.h>
#include <adc.h>
#include "asv_tmp.h"

#define	ASV_TMP_LED_OFF		1
#define ASV_TMP_LED_ON		0
#define ASV_TMP_DISP_NONE	10

#define ASV_TMP_LED_PORT	LATBbits.LATB3
#define ASV_TMP_7SEG1_PORT	LATCbits.LATC6
#define ASV_TMP_7SEG2_PORT	LATCbits.LATC7
#define ASV_TMP_7SEGA_PORT	LATCbits.LATC2
#define ASV_TMP_7SEGB_PORT	LATCbits.LATC1
#define ASV_TMP_7SEGC_PORT	LATCbits.LATC0
#define ASV_TMP_7SEGD_PORT	LATAbits.LATA5
#define ASV_TMP_7SEGE_PORT	LATAbits.LATA4
#define ASV_TMP_7SEGF_PORT	LATAbits.LATA3
#define ASV_TMP_7SEGG_PORT	LATAbits.LATA2
#define ASV_TMP_7SEGDOT_PORT	LATBbits.LATB1
#define ASV_TMP_SW_PORT		PORTBbits.RB2

void asv_tmp_disp_num(unsigned char);

unsigned char asv_tmp_7seg_disp_num = 0;
unsigned char asv_tmp_timer_7seg_disp = 0;
unsigned char asv_tmp_7seg_brightness = 0;

void asv_tmp_init(void)
{
	TRISA = 0x03;	//RA0,RA1����́A���͏o�͂ɐݒ�
	TRISB = 0x04;	//RB2����́A���͏o�͂ɐݒ�
	TRISC = 0x00;	//RC��S�ďo�͂ɐݒ�

	ASV_TMP_LED_PORT = ASV_TMP_LED_OFF;	//����LED������
	ASV_TMP_7SEG1_PORT = ASV_TMP_LED_OFF;	//�ꌅ�ڂ�OFF
	ASV_TMP_7SEG2_PORT = ASV_TMP_LED_OFF;	//�񌅖ڂ�OFF
	ASV_TMP_7SEGA_PORT = ASV_TMP_LED_OFF;	//a��OFF
	ASV_TMP_7SEGB_PORT = ASV_TMP_LED_OFF;	//b��OFF
	ASV_TMP_7SEGC_PORT = ASV_TMP_LED_OFF;	//a��OFF
	ASV_TMP_7SEGD_PORT = ASV_TMP_LED_OFF;	//b��OFF
	ASV_TMP_7SEGE_PORT = ASV_TMP_LED_OFF;	//a��OFF
	ASV_TMP_7SEGF_PORT = ASV_TMP_LED_OFF;	//b��OFF
	ASV_TMP_7SEGG_PORT = ASV_TMP_LED_OFF;	//a��OFF
	ASV_TMP_7SEGDOT_PORT = ASV_TMP_LED_OFF;	//b��OFF

	LATBbits.LATB4 = 0;	//ASOOVU���LED��OFF
	LATBbits.LATB5 = 0;

//�A�i���O�ݒ�
	ADCON0 = 0b00000001; //AN0, AD en
	ADCON1 = 0b00001101; //AN0/1�݂̂��g�p
	ADCON2 = 0b10101110; //�E�l�� 12Tad Fosc/64

	INTCON2bits.RBPU = 0;	//�����v���A�b�v��L���ɂ���
}

void asv_tmp_set_led(unsigned char led)
{
	if(led == 1)
		ASV_TMP_LED_PORT = ASV_TMP_LED_ON;
	else
		ASV_TMP_LED_PORT = ASV_TMP_LED_OFF;
}

void asv_tmp_set_7seg_num(unsigned char segnum)
{
	if(segnum < 101)
		asv_tmp_7seg_disp_num = segnum;
}

unsigned char asv_tmp_get_SW(void)
{
	return (ASV_TMP_SW_PORT);
}
void asv_tmp_disp7seg(void)
{
	unsigned char put_led[2];

	if(asv_tmp_7seg_disp_num == 255)
	{
		put_led[0] = ASV_TMP_DISP_NONE;
		put_led[1] = ASV_TMP_DISP_NONE;
	}
	else if(asv_tmp_7seg_disp_num == 100)
	{
		put_led[0] = 0;
		put_led[1] = 0;
	}
	else
	{
		put_led[0] = asv_tmp_7seg_disp_num % 10;
		if(asv_tmp_7seg_disp_num >= 10)
			put_led[1] = (asv_tmp_7seg_disp_num % 100)/10;
		else
			put_led[1] = ASV_TMP_DISP_NONE;
	}		

	asv_tmp_timer_7seg_disp++;
	if(asv_tmp_timer_7seg_disp == 1)
	{	//�ꌅ�ړ_��
		ASV_TMP_7SEG1_PORT = ASV_TMP_LED_ON;
		asv_tmp_disp_num(put_led[0]);
	}
	else if(asv_tmp_timer_7seg_disp == (5-asv_tmp_7seg_brightness))
	{	//�ꌅ�ڏ���
		ASV_TMP_7SEG1_PORT = ASV_TMP_LED_OFF;
		asv_tmp_disp_num(ASV_TMP_DISP_NONE);
	}
	else if(asv_tmp_timer_7seg_disp == 6)
	{	//�񌅖ړ_��
		ASV_TMP_7SEG2_PORT = ASV_TMP_LED_ON;
		asv_tmp_disp_num(put_led[1]);
	}
	else if(asv_tmp_timer_7seg_disp == (10-asv_tmp_7seg_brightness))
	{	//�񌅖ڏ���
		ASV_TMP_7SEG2_PORT = ASV_TMP_LED_OFF;
		asv_tmp_disp_num(ASV_TMP_DISP_NONE);
	}
	else if(asv_tmp_timer_7seg_disp >= 10)
	{	//�ꌅ�ڂɖ߂�
		asv_tmp_timer_7seg_disp = 0;
	}
}

void asv_tmp_set_7seg_brightness(unsigned char brightness)
{
	if(brightness < 4)
		asv_tmp_7seg_brightness = brightness;
}

void asv_tmp_disp_num(unsigned char num)
{
	LATA |= 0x3c;
	LATC |= 0x07;

	switch(num)
	{
		case 0:	LATA &= 0xc7;	LATC &= 0xf8;	break;
		case 1:	LATA &= 0xff;	LATC &= 0xfc;	break;
		case 2:	LATA &= 0xcb;	LATC &= 0xf9;	break;
		case 3:	LATA &= 0xdb;	LATC &= 0xf8;	break;
		case 4:	LATA &= 0xf3;	LATC &= 0xfc;	break;
		case 5:	LATA &= 0xd3;	LATC &= 0xfa;	break;
		case 6:	LATA &= 0xc3;	LATC &= 0xfa;	break;
		case 7:	LATA &= 0xf7;	LATC &= 0xf8;	break;
		case 8:	LATA &= 0xc3;	LATC &= 0xf8;	break;
		case 9:	LATA &= 0xd3;	LATC &= 0xf8;	break;
		default:	break;
	}
}

unsigned char asv_tmp_get_temperature(void)
{
	return ((long)((asv_tmp_get_analog(0)*1000L) - 102300L) / 2046L);
}

unsigned int asv_tmp_get_analog(unsigned char chan)
{
	switch(chan)
	{
		case 0:
			//AD�ϊ����� ���x�Z���T
			ADCON0 = 0b00000001;	//AN0
			ADCON0bits.GO = 1;
			while(ADCON0bits.GO);
			return (ReadADC());
			break;
		case 1:
			//AD�ϊ�����	�{�����[��
			ADCON0 = 0b00000101;	//AN1
			ADCON0bits.GO = 1;
			while(ADCON0bits.GO);
			return (ReadADC());
			break;
	}
	return 0;
}

