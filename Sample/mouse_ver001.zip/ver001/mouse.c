/*
	PIC18F2550 �����`��USB�pUSB�}�E�X�T���v��
		ver1.00	2010/11/11	����(MCHPFSUSB�̃T���v������쐬)

	�ڑ����Ă���ƃX�N���[���Z�C�o���N�����܂���	
*/

#ifndef USBMOUSE_C
#define USBMOUSE_C

/** INCLUDES *******************************************************/
#include "Microchip/Include/USB/usb.h"
#include "HardwareProfile.h"
#include "Microchip/Include/USB/usb_function_hid.h"
#include "bootload.h"

#define SSC_TIMER_COUNT	59000	//���̎��ԂɈ�x�A�}�E�X�𓮂����i1/1000�b�P��)

/** VARIABLES ******************************************************/
#pragma udata
char buffer[3];
USB_HANDLE lastTransmission;

unsigned int ssc_timer = SSC_TIMER_COUNT;

/** PRIVATE PROTOTYPES *********************************************/
void Emulate_Mouse(void);
static void InitializeSystem(void);
void ProcessIO(void);
void UserInit(void);

/** VECTOR REMAPPING ***********************************************/
#pragma code
	
void isr_high()
{
	#if defined(USB_INTERRUPT)
	USBDeviceTasks();
	#endif
}	//This return will be a "retfie fast", since this is in a #pragma interrupt section 
void isr_low()
{
}	//This return will be a "retfie", since this is in a #pragma interruptlow section 


/********************************************************************
 * Function:        void main(void)
 *******************************************************************/
void main(void)
{
    InitializeSystem();

    #if defined(USB_INTERRUPT)
        USBDeviceAttach();
    #endif

    while(1)
    {
        #if defined(USB_POLLING)
        USBDeviceTasks(); // Interrupt or polling method.  If using polling, must call
        #endif
    				  
        ProcessIO();        
    }//end while
}//end main


/********************************************************************
 * Function:        static void InitializeSystem(void)
 *******************************************************************/
static void InitializeSystem(void)
{
	ADCON1 |= 0x0F;                 // Default all pins to digital

    #if defined(USE_USB_BUS_SENSE_IO)
    tris_usb_bus_sense = INPUT_PIN; // See HardwareProfile.h
    #endif

    #if defined(USE_SELF_POWER_SENSE_IO)
    tris_self_power = INPUT_PIN;	// See HardwareProfile.h
    #endif
    
    UserInit();

    USBDeviceInit();	//usb_device.c.  Initializes USB module SFRs and firmware
    					//variables to known states.
}//end InitializeSystem



/******************************************************************************
 * Function:        void UserInit(void)
 *****************************************************************************/
void UserInit(void)
{
    //Initialize all of the mouse data to 0,0,0 (no movement)
    buffer[0]=buffer[1]=buffer[2]=0;

    lastTransmission = 0;
}//end UserInit


/********************************************************************
 * Function:        void ProcessIO(void)
 *******************************************************************/
void ProcessIO(void)
{   
    if((USBDeviceState < CONFIGURED_STATE)||(USBSuspendControl==1)) return;

    Emulate_Mouse();
    
}//end ProcessIO


/******************************************************************************
 * Function:        void Emulate_Mouse(void)
 *****************************************************************************/
void Emulate_Mouse(void)
{   

    if(HIDTxHandleBusy(lastTransmission) == 0)
    {
	    //������1/1000�b�Ɉ�x���s�����B
	    //����āASSC_TIMER_COUNT/1000�b�Ɉ��A�}�E�X�����ɂP�O�r�b�g�A�E�ɂP�O�r�b�g�҂����Ƃ�����
	   	ssc_timer--;
		if(ssc_timer == 2)
			buffer[1] = -10;
		if(ssc_timer == 1)
			buffer[1] = 10;
		if(ssc_timer == 0)
			ssc_timer = SSC_TIMER_COUNT;
	    
        //copy over the data to the HID buffer
        hid_report_in[0] = buffer[0];
        hid_report_in[1] = buffer[1];
        hid_report_in[2] = buffer[2];

		buffer[0] = 0;
		buffer[1] = 0;
		buffer[2] = 0;
     
        lastTransmission = HIDTxPacket(HID_EP, (BYTE*)hid_report_in, 0x03);
    }
}//end Emulate_Mouse


// ******************************************************************************************************
// ************** USB Callback Functions ****************************************************************
// ******************************************************************************************************
/******************************************************************************
 * Function:        void USBCBSuspend(void)
 *****************************************************************************/
void USBCBSuspend(void)
{
}

/******************************************************************************
 * Function:        void USBCBWakeFromSuspend(void)
 *****************************************************************************/
void USBCBWakeFromSuspend(void)
{
}

/********************************************************************
 * Function:        void USBCB_SOF_Handler(void)
 *******************************************************************/
void USBCB_SOF_Handler(void)
{
}

/*******************************************************************
 * Function:        void USBCBErrorHandler(void)
 *******************************************************************/
void USBCBErrorHandler(void)
{
}


/*******************************************************************
 * Function:        void USBCBCheckOtherReq(void)
 *******************************************************************/
void USBCBCheckOtherReq(void)
{
    USBCheckHIDRequest();
}//end


/*******************************************************************
 * Function:        void USBCBStdSetDscHandler(void)
 *******************************************************************/
void USBCBStdSetDscHandler(void)
{
}//end


/*******************************************************************
 * Function:        void USBCBInitEP(void)
 *******************************************************************/
void USBCBInitEP(void)
{
    USBEnableEndpoint(HID_EP,USB_IN_ENABLED|USB_HANDSHAKE_ENABLED|USB_DISALLOW_SETUP);
}

/********************************************************************
 * Function:        void USBCBSendResume(void)
 *******************************************************************/
void USBCBSendResume(void)
{
    static WORD delay_count;
    
    USBResumeControl = 1;                // Start RESUME signaling
    
    delay_count = 1800U;                // Set RESUME line for 1-13 ms
    do
    {
        delay_count--;
    }while(delay_count);
    USBResumeControl = 0;
}


/*******************************************************************
 * Function:        BOOL USER_USB_CALLBACK_EVENT_HANDLER(
 *                        USB_EVENT event, void *pdata, WORD size)
 *******************************************************************/
BOOL USER_USB_CALLBACK_EVENT_HANDLER(USB_EVENT event, void *pdata, WORD size)
{
    switch(event)
    {
        case EVENT_CONFIGURED: 
            USBCBInitEP();
            break;
        case EVENT_SET_DESCRIPTOR:
            USBCBStdSetDscHandler();
            break;
        case EVENT_EP0_REQUEST:
            USBCBCheckOtherReq();
            break;
        case EVENT_SOF:
            USBCB_SOF_Handler();
            break;
        case EVENT_SUSPEND:
            USBCBSuspend();
            break;
        case EVENT_RESUME:
            USBCBWakeFromSuspend();
            break;
        case EVENT_BUS_ERROR:
            USBCBErrorHandler();
            break;
        case EVENT_TRANSFER:
            Nop();
            break;
        default:
            break;
    }      
    return TRUE; 
}

/** EOF mouse.c *************************************************/
#endif

